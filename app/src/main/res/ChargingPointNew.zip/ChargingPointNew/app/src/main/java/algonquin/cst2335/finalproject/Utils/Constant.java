package algonquin.cst2335.finalproject.Utils;

public class Constant {

    public static String OpenChargeAPi_KEY = "831a4441-e9a1-4286-afa9-f32984a1b83f";
}
