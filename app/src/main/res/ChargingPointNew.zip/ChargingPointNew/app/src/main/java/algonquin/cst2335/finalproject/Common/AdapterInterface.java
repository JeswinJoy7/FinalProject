package algonquin.cst2335.finalproject.Common;


import algonquin.cst2335.finalproject.Model.AddressInfo;

public interface AdapterInterface {

    void onItemClicked(AddressInfo addressInfo);

}
